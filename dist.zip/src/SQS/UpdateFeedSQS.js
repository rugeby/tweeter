"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.UpdateFeedSQS = void 0;
class UpdateFeedSQS {
}
exports.UpdateFeedSQS = UpdateFeedSQS;
