"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PostStatusSQS = void 0;
class PostStatusSQS {
}
exports.PostStatusSQS = PostStatusSQS;
